
const { Router } = require("express");

const careerRoutes = require("./career.routes");
const progressRoutes = require("./progress.routes");
const userRoutes = require("./user.routes");
const universityRoutes = require("./university.routes");
const planImportRoutes = require("./planImport.routes");

const studyPlanRoutes = require("./studyPlan.routes");
const planSubjectRoutes = require("./planSubject.routes");

const router = Router();

// Información general
router.get("/", (req, res) => {
  res.json({
    name: "UNAHUR TP API",
    status: "ok",
    docs: "/api-docs",
    health: "/health",
  });
});

// Salud del backend
router.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

// Rutas existentes
router.use("/careers", careerRoutes);
router.use("/progress", progressRoutes);
router.use("/users", userRoutes);
router.use("/universities", universityRoutes);
router.use("/plan-imports", planImportRoutes);

// NUEVO: Materias de cada plan
router.use("/study-plans", planSubjectRoutes);

// NUEVO: Planes de estudio
router.use("/study-plans", studyPlanRoutes);

module.exports = router;
